#~/bin/bash
python create_thing.py
python create_topic_rule.py
