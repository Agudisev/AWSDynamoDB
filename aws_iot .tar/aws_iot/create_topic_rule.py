import json
import subprocess

file_setting='json/settings.json'
file_trust='json/iot-role-trust.json'
file_policy_dynamodb='json/iot-policy-dynamodb.json'
file_policy_passrole='json/iot-policy-passrole.json'
file_topic_rule_dynamodb='json/iot-topic-rule-dynamodb.json'
file_topic_rule_republish='json/iot-topic-rule-republish.json'

with open(file_setting) as json_file:
    aws_settings = json.load(json_file)

# Create DynamoDB table
print('Creating AWS DynamoDB Table: %s' % aws_settings['dynamoDbTableName'])
cmdline = 'aws dynamodb create-table --table-name ' + aws_settings['dynamoDbTableName'] + ' --attribute-definitions AttributeName=topic,AttributeType=S AttributeName=timestamp,AttributeType=N --key-schema AttributeName=topic,KeyType=HASH AttributeName=timestamp,KeyType=RANGE --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=5'
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
db_json=json.loads(out)
print('--> Created ARN: %s' % db_json["TableDescription"]["TableArn"])
print(err)

# Create role
print('Creating AWS IAM Role: %s' % aws_settings['roleName'])
role_name=aws_settings['roleName']
cmdline = 'aws iam create-role --role-name ' + role_name + ' --assume-role-policy-document file://' + file_trust
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
role_json=json.loads(out)
aws_settings['roleARN']=role_json["Role"]["Arn"]
print( "--> Created ARN: %s" % aws_settings['roleARN'] )
print(err)

# Create policy to full access DynamoDB
print('Creating AWS IAM policy to acess DynamoDB: %s' % aws_settings['policyDynamoDbName'])
policy_dynamodb_name=aws_settings['policyDynamoDbName']
cmdline = 'aws iam create-policy --policy-name ' + policy_dynamodb_name + ' --policy-document file://' + file_policy_dynamodb
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
policy_dynamodb_json=json.loads(out)
aws_settings['policyDynamoDbARN']=policy_dynamodb_json["Policy"]["Arn"]
print( "--> Created ARN: %s" % aws_settings['policyDynamoDbARN'] )
print(err)

# Attach role & policy(acces DynamoDB)
print('Attach IAM Role & Policy with DynamoDB access...')
cmdline = 'aws iam attach-role-policy --role-name ' + role_name + ' --policy-arn ' + aws_settings['policyDynamoDbARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# update role ARN in json/iot-policy-passrole.json
with open(file_policy_passrole) as policy_file:
    policy_passrole = json.load(policy_file)
policy_passrole["Statement"][0]["Resource"]=aws_settings['roleARN']
with open(file_policy_passrole, 'w') as policy_outfile:
    json.dump(policy_passrole, policy_outfile)

# Create policy to passRole
print('Creating AWS IAM policy for passRole: %s' % aws_settings['policyPassRoleName'])
cmdline = 'aws iam create-policy --policy-name ' + aws_settings['policyPassRoleName'] + ' --policy-document file://' + file_policy_passrole
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
policy_passrole_json=json.loads(out)
aws_settings['policyPassRoleARN']=policy_passrole_json["Policy"]["Arn"]
print( "--> Created ARN: %s" % aws_settings['policyPassRoleARN'] )
print(err)

# Attach role & policy(passRole)
print('Attach IAM Role & Policy with passRole...')
cmdline = 'aws iam attach-role-policy --role-name ' + role_name + ' --policy-arn ' + aws_settings['policyPassRoleARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Attach role & policy(AWSIoTFullAccess)
print('Attach IAM Role & Policy with AWSIoTFullAccess..')
cmdline = 'aws iam attach-role-policy --role-name ' + role_name + ' --policy-arn arn:aws:iam::aws:policy/AWSIoTFullAccess'
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# update DynamoDB tableName & roleArn in file_topic_rule_dynamodb
with open(file_topic_rule_dynamodb) as rule_file:
    rule = json.load(rule_file)
rule["sql"]="SELECT * FROM '" + aws_settings['thingName'] + "'"
rule["actions"][0]["dynamoDB"]["tableName"]=aws_settings['dynamoDbTableName']
rule["actions"][0]["dynamoDB"]["roleArn"]=aws_settings['roleARN']
with open(file_topic_rule_dynamodb, 'w') as rule_outfile:
    json.dump(rule, rule_outfile)

# Create topic rule for DynamoDB
print('Creating AWS IoT topic rule for DynamoDB: %s' % aws_settings['topicRuleDynamodbName'])
cmdline = 'aws iot create-topic-rule --rule-name ' + aws_settings['topicRuleDynamodbName'] + ' --topic-rule-payload file://' + file_topic_rule_dynamodb
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# update roleArn in file_topic_rule_republish
with open(file_topic_rule_republish) as rule_file:
    rule = json.load(rule_file)
rule["sql"]="SELECT moisture as state.reported.moisture, temp as state.reported.temp, pressure as state.reported.pressure, sequence as state.reported.sequence FROM '" + aws_settings['thingName'] + "'"
rule["actions"][0]["republish"]["topic"]="$$aws/things/"+aws_settings['thingName']+"/shadow/update"
rule["actions"][0]["republish"]["roleArn"]=aws_settings['roleARN']
with open(file_topic_rule_republish, 'w') as rule_outfile:
    json.dump(rule, rule_outfile)

# Create topic rule for republish
print('Creating AWS IoT topic rule for republish: %s' % aws_settings['topicRuleRepublishName'])
cmdline = 'aws iot create-topic-rule --rule-name ' + aws_settings['topicRuleRepublishName'] + ' --topic-rule-payload file://' + file_topic_rule_republish
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# update & write back
with open(file_setting, 'w') as outfile:
    json.dump(aws_settings, outfile)
