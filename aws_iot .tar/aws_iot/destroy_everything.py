import json
import re
import subprocess

file_setting='json/settings.json'

with open(file_setting) as json_file:
    aws_settings = json.load(json_file)

# Detach certificate from thing policy
print('Detach certificate from thing policy: %s' % aws_settings['thingPolicyName'])
print(' >> certARN: %s' % aws_settings['certificateArn'])
cmdline = 'aws iot detach-policy --policy-name ' + aws_settings['thingPolicyName'] + ' --target ' + aws_settings['certificateArn']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IoT thing policy
print('Delete AWS IoT thing policy: %s' % aws_settings['thingPolicyName'])
cmdline = 'aws iot delete-policy --policy-name ' + aws_settings['thingPolicyName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Detach certificate from shadow policy
print('Detach certificate from shadow policy: %s' % aws_settings['shadowPolicyName'])
print(' >> certARN: %s' % aws_settings['certificateArn'])
cmdline = 'aws iot detach-policy --policy-name ' + aws_settings['shadowPolicyName'] + ' --target ' + aws_settings['certificateArn']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IoT shadow policy
print('Delete AWS IoT shadow policy: %s' % aws_settings['shadowPolicyName'])
cmdline = 'aws iot delete-policy --policy-name ' + aws_settings['shadowPolicyName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Detach certificate from thing
print('Detach certificate from thing: %s' % aws_settings['thingName'])
print(' >> certARN: %s' % aws_settings['certificateArn'])
cmdline = 'aws iot detach-thing-principal --thing-name ' + aws_settings['thingName'] + ' --principal ' + aws_settings['certificateArn']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IoT Thing
print('Delete AWS IoT Thing: %s' % aws_settings['thingName'])
cmdline = 'aws iot delete-thing --thing-name ' + aws_settings['thingName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# INACTIVE AWS IoT Certificate
print('INACTIVE AWS IoT Certificate: %s' % aws_settings['certificateId'])
cmdline = 'aws iot update-certificate --certificate-id ' + aws_settings['certificateId'] + ' --new-status INACTIVE'
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IoT Certificate
print('Delete AWS IoT Certificate: %s' % aws_settings['certificateId'])
cmdline = 'aws iot delete-certificate --certificate-id ' + aws_settings['certificateId']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IoT Topic Rule
print('Delete AWS IoT Topic Rule: %s' % aws_settings['topicRuleDynamodbName'])
cmdline = 'aws iot delete-topic-rule --rule-name ' + aws_settings['topicRuleDynamodbName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IoT Topic Rule
print('Delete AWS IoT Topic Rule: %s' % aws_settings['topicRuleRepublishName'])
cmdline = 'aws iot delete-topic-rule --rule-name ' + aws_settings['topicRuleRepublishName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Detach IAM policy (full access DynamoDB) from IAM Role
print('Detach IAM policy from IAM Role: %s' % aws_settings['roleName'])
print(' >> certARN: %s' % aws_settings['policyDynamoDbARN'])
cmdline = 'aws iam detach-role-policy --role-name ' + aws_settings['roleName'] + ' --policy-arn ' + aws_settings['policyDynamoDbARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Detach IAM Policy (passRole) from IAM Role
print('Detach IAM Policy from IAM Role: %s' % aws_settings['roleName'])
print(' >> certARN: %s' % aws_settings['policyPassRoleARN'])
cmdline = 'aws iam detach-role-policy --role-name ' + aws_settings['roleName'] + ' --policy-arn ' + aws_settings['policyPassRoleARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Detach IAM Policy (AWSIoTFullAccess) from IAM Role
print('Detach IAM Policy from IAM Role: %s' % aws_settings['roleName'])
print(' >> certARN: %s' % aws_settings['policyPassRoleARN'])
cmdline = 'aws iam detach-role-policy --role-name ' + aws_settings['roleName'] + ' --policy-arn arn:aws:iam::aws:policy/AWSIoTFullAccess'
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IAM Role
print('Delete AWS IAM Role: %s' % aws_settings['roleName'])
cmdline = 'aws iam delete-role --role-name ' + aws_settings['roleName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IAM Policy to full access DynamoDB
print('Delete AWS IAM Policy to full access DynamoDB: %s' % aws_settings['policyDynamoDbARN'])
cmdline = 'aws iam delete-policy --policy-arn ' + aws_settings['policyDynamoDbARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IAM Policy to passRole
print('Delete AWS IAM Policy to passRole: %s' % aws_settings['policyPassRoleARN'])
cmdline = 'aws iam delete-policy --policy-arn ' + aws_settings['policyPassRoleARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS DynamoDB
print('Delete AWS DynamoDB: %s' % aws_settings['dynamoDbTableName'])
cmdline = 'aws dynamodb delete-table --table-name ' + aws_settings['dynamoDbTableName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

