import json
import re
import subprocess

file_setting='json/settings.json'

with open(file_setting) as json_file:
    aws_settings = json.load(json_file)

# Disable AWS IoT CloudWatch Logging
print('Disable AWS IoT CloudWatch Logging...')
cmdline = 'aws iot set-v2-logging-options --role-arn ' + aws_settings['roleLoggingARN'] + ' --default-log-level DISABLED'
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Detach IAM policy (CloudWatch) from IAM role 
print('Detach IAM policy from IAM role: %s' % aws_settings['roleLoggingName'])
print(' >> certARN: %s' % aws_settings['policyLoggingARN'])
cmdline = 'aws iam detach-role-policy --role-name ' + aws_settings['roleLoggingName'] + ' --policy-arn ' + aws_settings['policyLoggingARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IAM Policy to CloudWatch Logging 
#print('Delete AWS IAM Policy to CloudWatch logging: %s' % aws_settings['policyLoggingARN'])
#cmdline = 'aws iam delete-policy --policy-arn ' + aws_settings['policyLoggingARN']
#p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
#out, err = p.communicate()
#print('--> Done')
#print(err)

# Detach IAM policy (passRole) from IAM role 
print('Detach IAM policy from IAM role: %s' % aws_settings['roleLoggingName'])
print(' >> certARN: %s' % aws_settings['policyPassRoleARN'])
cmdline = 'aws iam detach-role-policy --role-name ' + aws_settings['roleLoggingName'] + ' --policy-arn ' + aws_settings['policyPassRoleARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IAM Policy to passRole
print('Delete AWS IAM Policy to passRole: %s' % aws_settings['policyPassRoleARN'])
cmdline = 'aws iam delete-policy --policy-arn ' + aws_settings['policyPassRoleARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Delete AWS IAM Role
print('Delete AWS IAM Role: %s' % aws_settings['roleLoggingName'])
cmdline = 'aws iam delete-role --role-name ' + aws_settings['roleLoggingName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

