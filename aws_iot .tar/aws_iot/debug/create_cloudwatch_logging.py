import json
import subprocess

file_setting='json/settings.json'
file_trust='json/iot-role-trust.json'
file_policy_passrole='json/iot-policy-passrole.json'
file_policy_logging='json/iot-policy-logging.json'

with open(file_setting) as json_file:
    aws_settings = json.load(json_file)

# Create role 
print('Creating AWS AIM Role: %s' % aws_settings['roleLoggingName'])
role_name=aws_settings['roleLoggingName']
cmdline = 'aws iam create-role --role-name ' + role_name + ' --assume-role-policy-document file://' + file_trust
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
role_json=json.loads(out)
aws_settings['roleLoggingARN']=role_json["Role"]["Arn"]
print( "--> Created ARN: %s" % aws_settings['roleLoggingARN'] )
print(err)

# Creating AWS IAM policy for CloudWatch logging
#print('Creating AWS IAM policy for CloudWatch logging: %s' % aws_settings['policyLoggingName'])
#cmdline = 'aws iam create-policy --policy-name ' + aws_settings['policyLoggingName'] + ' --policy-document file://' + file_policy_logging
#p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
#out, err = p.communicate()
#policy_logging_json=json.loads(out)
#aws_settings['policyLoggingARN']=policy_logging_json["Policy"]["Arn"]
#print( "--> Created ARN: %s" % aws_settings['policyLoggingARN'] )
#print(err)

# Attach role & policy(CloudWatch Logging)
print('Attach IAM Role & Policy with CloudWatch logging...')
cmdline = 'aws iam attach-role-policy --role-name ' + role_name + ' --policy-arn ' + aws_settings['policyLoggingARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Create policy to passRole
print('Creating AWS IAM policy for passRole: %s' % aws_settings['policyPassRoleName'])
cmdline = 'aws iam create-policy --policy-name ' + aws_settings['policyPassRoleName'] + ' --policy-document file://' + file_policy_passrole
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
policy_passrole_json=json.loads(out)
aws_settings['policyPassRoleARN']=policy_passrole_json["Policy"]["Arn"]
print( "--> Created ARN: %s" % aws_settings['policyPassRoleARN'] )
print(err)

# Attach role & policy(passRole)
print('Attach IAM Role & Policy with passRole...')
cmdline = 'aws iam attach-role-policy --role-name ' + role_name + ' --policy-arn ' + aws_settings['policyPassRoleARN']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Set AWS IoT CloudWatch Logging
print('Set AWS IoT CloudWatch Logging...')
cmdline = 'aws iot set-v2-logging-options --role-arn ' + aws_settings['roleLoggingARN'] + ' --default-log-level DEBUG'
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# update & write back
with open(file_setting, 'w') as outfile:
        json.dump(aws_settings, outfile)
