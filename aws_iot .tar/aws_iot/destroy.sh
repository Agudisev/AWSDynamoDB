#~/bin/bash
python destroy_everything.py
