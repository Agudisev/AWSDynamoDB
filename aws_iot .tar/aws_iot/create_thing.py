import json
import re
import subprocess

file_setting='json/settings.json'
file_thing_policy='json/iot-thing-policy.json'
file_shadow_policy='json/iot-shadow-policy.json'

with open(file_setting) as json_file:
    aws_settings = json.load(json_file)


thing_name=aws_settings['thingName']

# Create thing
print('Creating AWS IoT Thing: %s' % aws_settings['thingName'])
cmdline = 'aws iot create-thing --thing-name ' + thing_name + ' --attribute-payload {\"attributes\":{\"wattage\":\"75\",\"model\":\"123\"}}'
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
thing_json=json.loads(out)
print( "--> Created ARN: %s" % thing_json["thingArn"] )
print(err)
aws_settings['thingARN']=thing_json["thingArn"]

# Create Certificate/Public Key/Private Key
print('Creating AWS IoT Certificate/Public Key/Private Key: certFile: %s, publicKeyFile: %s, privateKeyFile: %s' %(aws_settings['certFile'], aws_settings['publicKeyFile'], aws_settings['privateKeyFile']))
cmdline = 'aws iot create-keys-and-certificate --set-as-active --certificate-pem-outfile ' + aws_settings['certFile'] + ' --public-key-outfile ' + aws_settings['publicKeyFile'] + ' --private-key-outfile ' + aws_settings['privateKeyFile']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
cert_json=json.loads(out)
print( "--> Created ARN: %s, Id: %s" % (cert_json["certificateArn"], cert_json["certificateId"]))
print(err)
aws_settings['certificateArn'] = cert_json["certificateArn"]
aws_settings['certificateId'] = cert_json["certificateId"]

# update resource in file_thing_policy
with open(file_thing_policy) as thing_policy_file:
    thing_policy = json.load(thing_policy_file)
# Connect policy resource:
thing_policy["Statement"][0]["Resource"]=[re.sub(r"thing/.*", "client/"+thing_name, aws_settings['thingARN'])]
# Publish policy resource:
thing_policy["Statement"][1]["Resource"]=[re.sub(r"thing/.*", "topic/"+thing_name, aws_settings['thingARN'])]
# Subscribe policy resource:
thing_policy["Statement"][2]["Resource"]=[re.sub(r"thing/.*", "topicfilter/"+thing_name, aws_settings['thingARN'])]
# Receive policy resource:
thing_policy["Statement"][3]["Resource"]=[re.sub(r"thing/.*", "topic/"+thing_name, aws_settings['thingARN'])]
with open(file_thing_policy, 'w') as thing_policy_file:
        json.dump(thing_policy, thing_policy_file)

# Create iot policy for thing
print('Creating AWS IoT thing policy: %s' % aws_settings['thingPolicyName'])
cmdline = 'aws iot create-policy --policy-name ' + aws_settings['thingPolicyName'] + ' --policy-document file://' + file_thing_policy
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
thing_policy_json=json.loads(out)
print( "--> Created ARN: %s" % thing_policy_json["policyArn"])
print(err)
aws_settings['thingPolicyARN'] = thing_policy_json["policyArn"]

# update resource in file_shadow_policy
with open(file_shadow_policy) as shadow_policy_file:
    shadow_policy = json.load(shadow_policy_file)
# Publish policy resource:
shadow_policy["Statement"][0]["Resource"]=[re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/update", aws_settings['thingARN'])]
shadow_policy["Statement"][0]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/delete", aws_settings['thingARN']))
shadow_policy["Statement"][0]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/get", aws_settings['thingARN']))
# Subscribe policy resource:
shadow_policy["Statement"][1]["Resource"]=[re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/update/accepted", aws_settings['thingARN'])]
shadow_policy["Statement"][1]["Resource"].append(re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/delete/accepted", aws_settings['thingARN']))
shadow_policy["Statement"][1]["Resource"].append(re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/get/accepted", aws_settings['thingARN']))
shadow_policy["Statement"][1]["Resource"].append(re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/update/rejected", aws_settings['thingARN']))
shadow_policy["Statement"][1]["Resource"].append(re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/delete/rejected", aws_settings['thingARN']))
#shadow_policy["Statement"][1]["Resource"].append(re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/get/rejected", aws_settings['thingARN']))
shadow_policy["Statement"][1]["Resource"].append(re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/update/delta", aws_settings['thingARN']))
shadow_policy["Statement"][1]["Resource"].append(re.sub(r"thing/.*", "topicfilter/$aws/things/"+thing_name+"/shadow/update/documents", aws_settings['thingARN']))
# Receive policy resource:
shadow_policy["Statement"][2]["Resource"]=[re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/update/accepted", aws_settings['thingARN'])]
shadow_policy["Statement"][2]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/delete/accepted", aws_settings['thingARN']))
shadow_policy["Statement"][2]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/get/accepted", aws_settings['thingARN']))
shadow_policy["Statement"][2]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/update/rejected", aws_settings['thingARN']))
shadow_policy["Statement"][2]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/delete/rejected", aws_settings['thingARN']))
#shadow_policy["Statement"][2]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/get/rejected", aws_settings['thingARN']))
shadow_policy["Statement"][2]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/update/delta", aws_settings['thingARN']))
shadow_policy["Statement"][2]["Resource"].append(re.sub(r"thing/.*", "topic/$aws/things/"+thing_name+"/shadow/update/documents", aws_settings['thingARN']))
# Shadow policy resource:
shadow_policy["Statement"][3]["Resource"]=[re.sub(r"thing/.*", "thing/"+thing_name, aws_settings['thingARN'])]
with open(file_shadow_policy, 'w') as shadow_policy_file:
        json.dump(shadow_policy, shadow_policy_file)

# Create iot policy for shadow
print('Creating AWS IoT shadow policy: %s' % aws_settings['shadowPolicyName'])
cmdline = 'aws iot create-policy --policy-name ' + aws_settings['shadowPolicyName'] + ' --policy-document file://' + file_shadow_policy
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
thing_policy_json=json.loads(out)
print( "--> Created ARN: %s" % thing_policy_json["policyArn"])
print(err)
aws_settings['shadowPolicyARN'] = thing_policy_json["policyArn"]

# Attach thing to certificate
print('Attach thing to certificate...')
cmdline = 'aws iot attach-thing-principal --principal ' + aws_settings['certificateArn'] + ' --thing-name ' + aws_settings['thingName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Attach iot thing policy to certificate
print('Attach IoT thing policy to certificate...')
cmdline = 'aws iot attach-policy --target ' + aws_settings['certificateArn'] + ' --policy-name ' + aws_settings['thingPolicyName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# Attach iot shadow policy to certificate
print('Attach IoT shadow policy to certificate...')
cmdline = 'aws iot attach-policy --target ' + aws_settings['certificateArn'] + ' --policy-name ' + aws_settings['shadowPolicyName']
p = subprocess.Popen(cmdline.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate()
print('--> Done')
print(err)

# update & write back
with open(file_setting, 'w') as outfile:
        json.dump(aws_settings, outfile)
